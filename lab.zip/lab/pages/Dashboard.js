import React from 'react';
import LeaveBalance from '../components/LeaveBalance';
import ApplyLeave from '../components/ApplyLeave';

const Dashboard = () => {
  return (
    <div>
      <h1>Staff Dashboard</h1>
      <LeaveBalance />
      <ApplyLeave />
    </div>
  );
};

export default Dashboard;
