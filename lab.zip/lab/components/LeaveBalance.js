import React, { useState, useEffect } from 'react';
import axios from 'axios';

const LeaveBalance = () => {
  const [balance, setBalance] = useState({
    casual: 0,
    medical: 0,
    emergency: 0,
  });

  useEffect(() => {
    // Fetch leave balance from API
    axios.get('/api/leave-balance')
      .then(response => setBalance(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <div>
      <h2>Leave Balance</h2>
      <ul>
        <li>Casual Leave: {balance.casual}</li>
        <li>Medical Leave: {balance.medical}</li>
        <li>Emergency Leave: {balance.emergency}</li>
      </ul>
    </div>
  );
};

export default LeaveBalance;
