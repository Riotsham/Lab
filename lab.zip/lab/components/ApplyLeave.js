import React, { useState } from 'react';
import axios from 'axios';

const ApplyLeave = () => {
  const [form, setForm] = useState({
    type: 'casual',
    days: 1,
    reason: '',
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('/api/apply-leave', form)
      .then(response => alert(response.data.message))
      .catch(error => console.error(error));
  };

  return (
    <div>
      <h2>Apply for Leave</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Leave Type:
          <select name="type" value={form.type} onChange={handleChange}>
            <option value="casual">Casual</option>
            <option value="medical">Medical</option>
            <option value="emergency">Emergency</option>
          </select>
        </label>
        <br />
        <label>
          Days:
          <input
            type="number"
            name="days"
            value={form.days}
            onChange={handleChange}
            min="1"
          />
        </label>
        <br />
        <label>
          Reason:
          <textarea
            name="reason"
            value={form.reason}
            onChange={handleChange}
          />
        </label>
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ApplyLeave;
